% Program 8_7
% Cascaded Lattice Realization of a Pair of FIR Transfer Functions
%
format long
[del,gamma,splcase] = tfpair2latc;
disp('Lattice coefficients delta are'); disp(del);
disp('Lattice coefficients gamma are'); disp(gamma);
